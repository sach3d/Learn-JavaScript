<html>
<body>

Welcome <?php echo $_POST["name"]; ?><br>
Your phone number is: <?php echo $_POST["codes"] . echo $_POST["phone"]; ?><br>
You are: <?php echo $_POST["gender"]; ?><br>
Your birth day are: <?php echo $_POST["day"] . echo $_POST["month"] . echo $_POST["year"]; ?><br>

</body>
</html> 